from Monitoramento import exibir_veiculos, exibir_cargas, exibir_janelas, exibir_telemetria, diagnostico_geral

exibir_veiculos()
exibir_cargas()
exibir_janelas()
exibir_telemetria()
diagnostico_geral()