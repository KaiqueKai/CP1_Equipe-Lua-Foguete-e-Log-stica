from kit_dados import veiculos_logisticos, cargas, locais_pouso_apollo
from Monitoramento import alocar_carga_no_veiculo, avaliar_viagem_por_local, calcular_perigo_missao

print(f'{"SIMULAÇÃO DE MISSÃO LOGÍSTICA":^60}')
print(f'{"=~" * 30}')

print('\nVeículos disponíveis:')
for i, veiculo in enumerate(veiculos_logisticos):
    print(f'{i} - {veiculo["modelo"]}')

indice_veiculo = int(input('\nEscolha o número do veículo: '))
veiculo_escolhido = veiculos_logisticos[indice_veiculo]

print('\nCargas disponíveis:')
for i, carga in enumerate(cargas):
    print(f'{i} - {carga["tipo"]} ({carga["massa_kg"]} kg)')

indice_carga = int(input('\nEscolha o número da carga: '))
carga_escolhida = cargas[indice_carga]

print('\nLocais de pouso (Apollo):')
for i, local in enumerate(locais_pouso_apollo):
    print(f'{i} - {local["local"]} ({local["missao"]})')

indice_local = int(input('\nEscolha o número do local: '))
local_escolhido = locais_pouso_apollo[indice_local]

grau_carga, veiculo_carregado = alocar_carga_no_veiculo(veiculo_escolhido, carga_escolhida)
missao, grau_local = avaliar_viagem_por_local(veiculo_carregado, local_escolhido)
resultado_final = calcular_perigo_missao(grau_carga, grau_local)

print('\n' + f'{"RESULTADO DA SIMULAÇÃO":^60}')
print(f'{"=~" * 30}')
print(f' Veículo: {veiculo_escolhido["modelo"]}')
print(f' Carga: {carga_escolhida["tipo"]} ({carga_escolhida["massa_kg"]} kg)')
print(f' Destino: {missao["local"]} ({missao["missao_ref"]})')
print(f' Combustível suficiente: {"SIM" if missao["combustivel_ok"] else "NÃO"}')
print(f' Bateria suficiente: {"SIM" if missao["bateria_ok"] else "NÃO"}')
print(f' Classificação final: {resultado_final}')

recomendacoes = {
    'NORMAL': 'Missão dentro dos parâmetros esperados, pode prosseguir.',
    'ALERTA': 'Missão viável, mas exige atenção aos recursos disponíveis.',
    'CRITÍCA': 'Missão arriscada, recomenda-se revisar veículo ou carga antes de prosseguir.',
    'MISSÂO CONDENADA': 'Missão não recomendada com os recursos atuais.'
}
print(f' Recomendação: {recomendacoes[resultado_final]}')

print(f'{"=~" * 30}')