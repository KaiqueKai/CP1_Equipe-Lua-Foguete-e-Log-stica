# KIT DE DADOS — FOGUETE E LOGISTICA
# Bases para projetos de transporte de carga, selecao de veiculos, pouso e planejamento logistico.

veiculos_logisticos = [
    {"id": "LV-01", "modelo": "Lander A", "carga_max_kg": 1200, "combustivel_pct": 92, "status": "disponivel"},
    {"id": "LV-02", "modelo": "Lander Cargo", "carga_max_kg": 2200, "combustivel_pct": 81, "status": "disponivel"},
    {"id": "LV-03", "modelo": "Ascent X", "carga_max_kg": 850, "combustivel_pct": 74, "status": "manutencao"},
    {"id": "LV-04", "modelo": "Cargo Heavy", "carga_max_kg": 3200, "combustivel_pct": 88, "status": "disponivel"},
    {"id": "LV-05", "modelo": "Crew Lander", "carga_max_kg": 900, "combustivel_pct": 95, "status": "disponivel"},
    {"id": "LV-06", "modelo": "Supply Lander", "carga_max_kg": 1700, "combustivel_pct": 84, "status": "disponivel"}
]

cargas = [
    {"id": "CG-01", "tipo": "alimentos", "massa_kg": 620, "prioridade": 1},
    {"id": "CG-02", "tipo": "baterias", "massa_kg": 980, "prioridade": 1},
    {"id": "CG-03", "tipo": "equipamento cientifico", "massa_kg": 740, "prioridade": 3},
    {"id": "CG-04", "tipo": "pecas habitat", "massa_kg": 1350, "prioridade": 2},
    {"id": "CG-05", "tipo": "agua", "massa_kg": 1800, "prioridade": 1},
    {"id": "CG-06", "tipo": "rover leve", "massa_kg": 2050, "prioridade": 2}
]

telemetria_pouso = [
    {"tempo_s": 0, "altitude_m": 1800, "velocidade_ms": 58, "combustivel_pct": 72, "temp_motor_c": 410, "vibracao": 1.8},
    {"tempo_s": 15, "altitude_m": 1280, "velocidade_ms": 46, "combustivel_pct": 68, "temp_motor_c": 438, "vibracao": 2.0},
    {"tempo_s": 30, "altitude_m": 820, "velocidade_ms": 33, "combustivel_pct": 63, "temp_motor_c": 462, "vibracao": 2.3},
    {"tempo_s": 45, "altitude_m": 430, "velocidade_ms": 21, "combustivel_pct": 58, "temp_motor_c": 486, "vibracao": 2.7},
    {"tempo_s": 60, "altitude_m": 160, "velocidade_ms": 11, "combustivel_pct": 53, "temp_motor_c": 501, "vibracao": 3.0},
    {"tempo_s": 75, "altitude_m": 28, "velocidade_ms": 4, "combustivel_pct": 49, "temp_motor_c": 493, "vibracao": 2.5}
]

janelas_operacao = [
    {"janela": "J1", "duracao_min": 32, "prioridade": 1, "risco": "baixo"},
    {"janela": "J2", "duracao_min": 25, "prioridade": 2, "risco": "medio"},
    {"janela": "J3", "duracao_min": 41, "prioridade": 1, "risco": "baixo"},
    {"janela": "J4", "duracao_min": 18, "prioridade": 3, "risco": "alto"},
    {"janela": "J5", "duracao_min": 36, "prioridade": 2, "risco": "medio"},
    {"janela": "J6", "duracao_min": 29, "prioridade": 1, "risco": "medio"}
]

# 0 = adequado | 1 = atencao | 2 = alto risco
mapa_zonas_pouso = [
    [0, 0, 1, 1, 2, 2],
    [0, 0, 0, 1, 1, 2],
    [1, 0, 0, 0, 1, 1],
    [1, 1, 0, 0, 0, 1],
    [2, 1, 1, 0, 0, 0],
    [2, 2, 1, 1, 0, 0]
]

# Referencia historica NASA: locais e tempos das seis alunissagens Apollo tripuladas.
locais_pouso_apollo = [
    {"missao": "Apollo 11", "local": "Mare Tranquillitatis", "coordenada": (0.67416, 23.47314), "horas_lm": 21.6, "horas_eva": 2.5},
    {"missao": "Apollo 12", "local": "Oceanus Procellarum", "coordenada": (-3.0128, -23.4219), "horas_lm": 31.5, "horas_eva": 7.8},
    {"missao": "Apollo 14", "local": "Fra Mauro Highlands", "coordenada": (-3.64589, -17.47194), "horas_lm": 33.5, "horas_eva": 9.4},
    {"missao": "Apollo 15", "local": "Hadley Rille", "coordenada": (26.13239, 3.63330), "horas_lm": 66.9, "horas_eva": 19.1},
    {"missao": "Apollo 16", "local": "Descartes Highlands", "coordenada": (-8.9734, 15.5011), "horas_lm": 71.0, "horas_eva": 20.2},
    {"missao": "Apollo 17", "local": "Taurus-Littrow Valley", "coordenada": (20.1911, 30.7655), "horas_lm": 75.0, "horas_eva": 22.1}
]

